/** Automatically generated file. DO NOT MODIFY */
package edu.np.ece.mapg.navigationdrawer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}