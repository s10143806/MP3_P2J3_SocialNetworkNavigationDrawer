package edu.np.ece.mapg.navigationdrawer;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class MainActivity extends Activity implements OnItemClickListener {

	private DrawerLayout drawerLayout;
	private ListView listView;
	private String[] socialTitle;
	private ActionBarDrawerToggle drawerListener;
	private CharSequence mDrawerTitle, mTitle;

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mTitle = mDrawerTitle = getTitle();
        drawerLayout= (DrawerLayout) this.findViewById(R.id.drawer_layout);
        socialTitle = getResources().getStringArray(R.array.items);
        listView = (ListView) this.findViewById(R.id.slider_list); 
        
        //set adapter for the listview
        listView.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,socialTitle));
        //set the list's listener
        listView.setOnItemClickListener(new SlideMenuClickListener());
        
        drawerListener = new ActionBarDrawerToggle(this, drawerLayout,R.drawable.ic_drawer, R.string.app_name, R.string.app_name){
        	
        	@Override
        	/** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getActionBar().setTitle(mTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
            	
                super.onDrawerOpened(drawerView); 
                getActionBar().setTitle(mDrawerTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }            
            
        };
        drawerLayout.setDrawerListener(drawerListener);  
        getActionBar().setHomeButtonEnabled(true);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        
    }
  
    
    private class SlideMenuClickListener implements
    ListView.OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			displayView(position);
		}
    	
    }
    private void displayView(int position) {
        // update the main content by replacing fragments
        Fragment fragment = null;
        switch (position) {
        case 0:
            fragment = new HomeFragment();
            break;
        case 1:
            fragment = new GooglePlus();
            break;
        case 2:
            fragment = new Facebook();
            break;
        case 3:
            fragment = new Twitter();
            break;
        case 4:
            fragment = new Youtube();
            break;
        case 5:
            fragment = new Flickr();
            break;
        case 6:
            fragment = new Pinterest();
            break;
        case 7:
            fragment = new Instagram();
            break;
       
        default: fragment = new Instagram();
            break;
        }
 
        if (fragment != null) {
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.frame_container, fragment).commit();
 
            // update selected item and title, then close the drawer
            listView.setItemChecked(position, true);
            listView.setSelection(position);
            setTitle(socialTitle[position]);
            drawerLayout.closeDrawer(listView);
        } else {
            // error in creating fragment
            Log.e("MainActivity", "Error in creating fragment");}
        }
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // If the nav drawer is open, hide action items related to the content view
        boolean drawerOpen = drawerLayout.isDrawerOpen(listView);
        menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState)
    {
    	super.onPostCreate(savedInstanceState);
    	drawerListener.syncState();
    }
    
    public void selectItem(int position){
    	listView.setItemChecked(position, true);
    }
    
  
     @Override
     public void onItemClick(AdapterView<?> parent, View view,int position, long id){
    	 
    	 setTitle(socialTitle[position]);
     }
     
     public void setTitle(String title)
     {
    	 mTitle = title;
    	 getActionBar().setTitle(title);
     }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
       drawerListener.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	if(drawerListener.onOptionsItemSelected(item))
    	{
    		return true;
    	}
    	return super.onOptionsItemSelected(item);
       
    }
}
